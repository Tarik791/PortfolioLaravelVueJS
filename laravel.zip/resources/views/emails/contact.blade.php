<h1> Contact from {{ $name }} </h1>
<p> {{$body}} </p> <br>
From the {{ $email }}