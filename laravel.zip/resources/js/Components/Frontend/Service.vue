<script setup>

</script>
<template>
    <section id="services" class="section bg-dark-secondary dark:border-dark-secondary">
        <div class="container mx-auto">
            <div class="flex flex-col items-center text-center">
                <h2 class="section-title">What I do for clients?</h2>
                <div class="subtitle">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere officiis pariatur nulla assumenda modi ea id est molestias velit perspiciatis.
                </div>
            </div>
            <div class="grid lg:grid-cols-4 gap-8">
                <div class="bg-light-tail-100 dark:bg-dark-navy-500 p-6 rounded-2xl">
                    <div class="h-24 w-24">
                        <img class="object-cover h-full w-full md:mx-auto lg:mx-0 rounded-2xl" src="http://127.0.0.1:8000/img/work.jpg" alt="about">

                    </div>
                    <h4 class="text-xl font-medium mb-2">Web Design</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae, sequi explicabo quae veritatis quaerat commodi?</p>
                </div>
                <div class="bg-light-tail-100 dark:bg-dark-navy-500 p-6 rounded-2xl">
                    <div class="h-24 w-24">
                        <img class="object-cover h-full w-full md:mx-auto lg:mx-0 rounded-2xl" src="http://127.0.0.1:8000/img/work.jpg" alt="about">

                    </div>
                    <h4 class="text-xl font-medium mb-2">Web Design</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae, sequi explicabo quae veritatis quaerat commodi?</p>
                </div>

                <div class="bg-light-tail-100 dark:bg-dark-navy-500 p-6 rounded-2xl">
                    <div class="h-24 w-24">
                        <img class="object-cover h-full w-full md:mx-auto lg:mx-0 rounded-2xl" src="http://127.0.0.1:8000/img/work.jpg" alt="about">

                    </div>
                    <h4 class="text-xl font-medium mb-2">Web Design</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae, sequi explicabo quae veritatis quaerat commodi?</p>
                </div>

                <div class="bg-light-tail-100 dark:bg-dark-navy-500 p-6 rounded-2xl">
                    <div class="h-24 w-24">
                        <img class="object-cover h-full w-full md:mx-auto lg:mx-0 rounded-2xl" src="http://127.0.0.1:8000/img/work.jpg" alt="about">

                    </div>
                    <h4 class="text-xl font-medium mb-2">Web Design</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae, sequi explicabo quae veritatis quaerat commodi?</p>
                </div>
               
            </div>
            
            
        </div>
        
    </section>
</template>