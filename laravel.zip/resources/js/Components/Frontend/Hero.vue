<script setup>


</script>
<template>
    <section id="home" class="lg:h-[85vh] flex items-center bg-light-primary dark:bg-dark-primary py-32 lg:py-0 overflow-hidden">
        <div class="container mx-auto h-full">
            <div class="flex flex-col md:flex-row items-center h-full pt-8">
                <div class="flex-1 flex flex-col items-center lg:items-start">

                <p class="text-lg text-accent text-md mb-[22px]">Hey, I'm Tarik! </p>
                <h1 class="text-4xl leading-[44px] md:text-5xl md:leading-tight lg:text-7xl lg:leading-[1.2] font-bold md:tracking-[-2px]">I Build & Design <br> Web Interfaces.</h1>
                <p class="pt-4 pb-8 md:pt-6 md:pb-12 max-w-[480px] text-lg text-center lg:text-left">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum, veniam.
                </p>
                <button class="btn btn-md bg-accent hover:dark:bg-dark-tail-100 hover:text-light-primary md:btn-lg transition-all">
                    Work with me
                </button>
                <div class="pt-12">
                    <h5 class="text-lg flex items-center text-black dark:text-white mb-2">Follow me on </h5>
                    <div class="flex items-center mb-6">
                        <div class="p-1">
                        <a href=""  class=" w-12 h-12 rounded-full flex items-center justify-center border border-white text-black bg-blue-700 hover:bg-light-secondary hover:border-light-secondary dark:hover:bg-dark-secondary dark:hover:border-dark-secondary">
                        <img src="http://127.0.0.1:8000/img/facebook.png" alt="about">
                        
                        </a>
                    </div>
                    <div class="p-1">
                        <a href=""  class="w-12 h-12 rounded-full flex items-center justify-center border border-white text-black bg-blue-700 hover:bg-light-secondary hover:border-light-secondary dark:hover:bg-dark-secondary dark:hover:border-dark-secondary">
                            <img src="http://127.0.0.1:8000/img/github.png" alt="about">
                            
                            </a>
                        </div>
                        <div class="p-1">
                            <a href=""  class="w-12 h-12 rounded-full flex items-center justify-center border border-white text-black bg-blue-700 hover:bg-light-secondary hover:border-light-secondary dark:hover:bg-dark-secondary dark:hover:border-dark-secondary">
                                <img src="http://127.0.0.1:8000/img/linkedin.png" alt="about">
                                
                            </a>
                        </div>
                        
                    </div>
                    
                </div>
            </div>
            <div class="flex flex-1 justify-end items-center h-full mt-8 md:mt-0">
                <img class="rounded-lg" src="https://previews.123rf.com/images/rostislavsedlacek/rostislavsedlacek1805/rostislavsedlacek180500032/102531020-top-view-of-office-work-desk-with-laptop-on-white-background.jpg?fj=1" >
            </div>
            </div>
        </div>
    </section>
</template>